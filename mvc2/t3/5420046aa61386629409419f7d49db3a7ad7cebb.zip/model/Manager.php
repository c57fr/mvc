<?php
namespace Cb74\Blog\Model;

class Manager {
    protected function dbConnect()
    {
        $db = new \PDO('mysql:host=localhost;dbname=blog;charset=utf8', 'user', 'user');
        return $db;
    }
}