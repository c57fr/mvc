<header>
    <div style="text-align: center; font-family: 'Comic Sans MS', arial; padding: 10px; background-color: orange; border-radius: 7px">
        <h1 style="font-size:2em; font-weight: bold; line-height:1; margin:20px"><a style="text-decoration: none" href="http://c57.fr" target="_blank"> c57.fr</a></h1>
        <p>Pour apprendre en co-créant</p>
    </div>
    <p style="margin-top: 0; text-align:right; font-style: italic"><a style="text-decoration: none" href="https://github.com/c57fr/mvc" target="_blank">Dépôt GitHub</a></p>
</header>
